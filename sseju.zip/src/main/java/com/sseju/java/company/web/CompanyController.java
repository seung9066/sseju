package com.sseju.java.company.web;

import org.springframework.stereotype.Controller;

@Controller
public class CompanyController {
	
	

}
